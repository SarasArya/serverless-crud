Properties in AttributeDefinitions should match KeySchema. You only need to declare the indexes rest you can go add along the way. That's the beauty of NO SQL
